# Major Project Midpoint Submission

## Compile

This following command creates the `fuzzer` binary which is staticially linked.

```
make
```

## Run

```
./fuzzer /path/to/data /path/to/binary
```

#ifndef _FUZZ_CSV_H_
#define _FUZZ_CSV_H_

#include "fuzzer.h"

/* The handle for fuzzing csv files, does not return */
void fuzz_handle_csv(struct state *);

#endif /* _FUZZ_CSV_H_ */

